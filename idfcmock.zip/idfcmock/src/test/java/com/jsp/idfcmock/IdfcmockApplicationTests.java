package com.jsp.idfcmock;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdfcmockApplicationTests {

	@Test
	void contextLoads() {
	}

}
