package com.jsp.idfcmock.dto;

import org.springframework.stereotype.Component;


import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Component
@Entity
public class EmployeeDto {

	@Id
	private String emp_emailid;
	private int emp_id;
	private String emp_name;
	private String emp_phnno;
	
	public String getEmp_emailid() {
		return emp_emailid;
	}
	public void setEmp_emailid(String emp_emailid) {
		this.emp_emailid = emp_emailid;
	}
	public int getEmp_id() {
		return emp_id;
	}
	public void setEmp_id(int emp_id) {
		this.emp_id = emp_id;
	}
	public String getEmp_name() {
		return emp_name;
	}
	public void setEmp_name(String emp_name) {
		this.emp_name = emp_name;
	}
	public String getEmp_phnno() {
		return emp_phnno;
	}
	public void setEmp_phnno(String emp_phnno) {
		this.emp_phnno = emp_phnno;
	}
	
	
	
}