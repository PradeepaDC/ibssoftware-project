package com.jsp.idfcmock.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.idfcmock.dto.EmployeeDto;

public interface UserRepository extends JpaRepository<EmployeeDto, String> {

}
